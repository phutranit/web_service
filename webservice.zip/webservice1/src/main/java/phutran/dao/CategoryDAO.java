package phutran.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import phutran.model.Category;

@Repository
public class CategoryDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Category> getItems() {
		return jdbcTemplate.query("select * from categories order by cid desc",
				new BeanPropertyRowMapper<Category>(Category.class));
	}

	public Category getItem(int id) {
		return jdbcTemplate.queryForObject("select * from categories where cid = ?", new Object[] { id },
				new BeanPropertyRowMapper<Category>(Category.class));
	}

	public int addItem(Category category) {
		return jdbcTemplate.update("insert into categories(cid,cname) values(?,?)",
				new Object[] { category.getCid(), category.getCname() });
	}

	public int editItem(Category category) {
		return jdbcTemplate.update("update categories set cname = ? where cid = ?",
				new Object[] { category.getCname(), category.getCid() });
	}

	public int delItem(int id) {
		return jdbcTemplate.update("delete from categories where cid = ?  ", new Object[] { id });
	}

}