package phutran.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import phutran.model.Category;

@Controller
public class ReadCatController {

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/catdemo", method = RequestMethod.GET)
	@ResponseBody
	public void getCats() {
		String json = "http://localhost:8080/webservice1/cat";
		ObjectMapper om = new ObjectMapper();
		ArrayList<Category> listCat = null;
		try {
			listCat = (ArrayList<Category>) om.readValue(new URL(json), new TypeReference<ArrayList<Category>>() {
			}); 
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for (Category category : listCat) {
			System.out.println(category);
		}
		
	}

}
