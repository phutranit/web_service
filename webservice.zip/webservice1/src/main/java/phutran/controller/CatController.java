package phutran.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import phutran.dao.CategoryDAO;
import phutran.model.Category;

@RestController
public class CatController {
	@Autowired
	private CategoryDAO catDAO;

	@RequestMapping(value = "/cat", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Category> getCats() {
		List<Category> list = catDAO.getItems();
		return list;
	}

	@RequestMapping(value = "/cat/{id}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })

	public Category getEmployee(@PathVariable("id") int id) {
		return catDAO.getItem(id);
	}

	@RequestMapping(value = "/cat", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })

	public Category addCat(@RequestBody Category cat) {
		catDAO.addItem(cat);
		return cat;
	}

	@RequestMapping(value = "/cat", method = RequestMethod.PUT, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Category editCat(@RequestBody Category cat) {
		catDAO.editItem(cat);
		return cat;
	}

	@RequestMapping(value = "/cat/{id}", method = RequestMethod.DELETE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public void delItem(@PathVariable("id") int id) {
		catDAO.delItem(id);
		System.out.println("DELETE SUCCUES");
	}
}
